<template>
  <button class="test_btn">Пройти</button>
</template>
<style scoped>
.test_btn{
  position: absolute;
  border-radius: 16px;
  background: #FFF;
  padding: 12px 24px;
  color: #0A2B49;
  font-family: Manrope;
  font-size: 24px;
  font-style: normal;
  font-weight: 600;
  line-height: 120%; /* 28.8px */;
  max-width: 136px;
  margin-left: 20px;
  margin-bottom: 20px;
  bottom: 1px;
  border: none;
  cursor: pointer;
}
.test_btn:hover{
  color: #FFF;
  background: #0A2B49;
}
</style>
<script setup>
</script>
