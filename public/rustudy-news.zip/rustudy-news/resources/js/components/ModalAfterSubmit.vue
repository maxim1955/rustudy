<template>
    <div class="modal__offer modal-submit">
        <div class="modal__overlay">
            <div class="modal__window">
                <button class="btn-reset btn-close" @click="$emit('close-submit')"></button>
                <p class="modal__title">Спасибо, ваш заказ успешно оформлен</p>
                <p class="modal__text">Наши специалисты свяжутся с вами в ближайшее время для уточнения деталей заказа</p>
                <img src="img/after-submit-illustration.webp" alt="">
            </div>
        </div>
    </div>
</template>

<script>
    export default {

    }
</script>
