<template>
    <div>
        <router-view></router-view>
    </div>
</template>
<style>
@import "../../public/css/style.css";
@import "../../public/css/service.css";
@import "../../public/css/media.css";
@import "../../public/css/modal-offer.css";
@import "../../public/css/book.css";
@import "../../public/css/news.css";

</style>

